if (sessionStorage.getItem("girisYapildi") !== "1") {
    window.location.href = "Login.html"
}