if (sessionStorage.getItem("girisYapildi") !== "1") {
    window.location.href = "Login.html"
}
// ID LERİN TANIMI
const acıklamaİnput = document.getElementById("txDesc");
const tutarİnput = document.getElementById("txAmount");
const ekleBtn = document.getElementById("submit"); 
const silBtn = document.getElementById("clearAll"); 
const türİnput = document.getElementById("txType");
const listArea = document.getElementById("txList");

// KUTULARIN ID TANIMI
const gelirKutusu = document.getElementById("income");
const giderKutusu = document.getElementById("expense");
const bakiyeKutusu = document.getElementById("balance");

let islemler = [];

//  SAYFA YÜKLENİNCE VERİLERİ ÇEK
window.addEventListener("load", function() {
    const gelenVeri = localStorage.getItem("harcamalar");
    if (gelenVeri !== null) {
        islemler = JSON.parse(gelenVeri);
    }
    ekranaYazdır(); 
});

//  EKLEME BUTONU
if (ekleBtn) {
    ekleBtn.addEventListener("click", function (event) {
        event.preventDefault();

        const acıklamaValue = acıklamaİnput.value;
        const tutarValue = tutarİnput.value;
        const türValue = türİnput.value;

        if (acıklamaValue == "" || tutarValue == "") {
            alert("Lütfen alanları doldurunuz!");
            return;
        }
        
        const yeniİşlem = {
            id: Date.now(),
            acıklama: acıklamaValue,
            tutar: Number(tutarValue),
            tür: türValue
        };

        islemler.push(yeniİşlem);
        localStorage.setItem("harcamalar", JSON.stringify(islemler));
        
        ekranaYazdır();

        acıklamaİnput.value = "";
        tutarİnput.value = "";
    });
} else {
    console.error("HATA: HTML dosyasında id='submit' olan buton bulunamadı!");
}

// 4. TÜMÜNÜ SİL BUTONU 
if (silBtn) {
    silBtn.addEventListener("click", function() {
        if (confirm("Tüm listeyi temizlemek istediğine emin misin?")) {
            
            islemler = []; 
            
            localStorage.setItem("harcamalar", JSON.stringify(islemler));
            
            
            ekranaYazdır();
        }
    });
}

// 5. SATIR SİLME
window.Sil = function(silinecekId) {
    
    islemler = islemler.filter(islem => islem.id !== silinecekId);
    
    
    localStorage.setItem("harcamalar", JSON.stringify(islemler));
    

    ekranaYazdır();
}

// 6. EKRANA YAZDIRMA VE HESAPLAMA 
function ekranaYazdır() {
    listArea.innerHTML = "";
    
    
    let toplamGelir = 0;
    let toplamGider = 0;

    islemler.forEach(function (islem) {
        
        
        const sayiTutar = Number(islem.tutar);
        
        if(islem.tür === "income") {
            toplamGelir += sayiTutar;
        } else {
            toplamGider += sayiTutar;
        }

        const renk = islem.tür === "income" ? "text-success" : "text-danger";
        const isaret = islem.tür === "income" ? "+" : "-";

        const yeniSatır = document.createElement("li");
        yeniSatır.className = "list-group-item d-flex justify-content-between align-items-center";

        yeniSatır.innerHTML = ` 
            <span>${islem.acıklama}</span>
            <div>
                <span class="${renk} fw-bold me-3">
                    ${isaret}${islem.tutar} ₺
                </span>
                <button onclick="Sil(${islem.id})" class="btn btn-sm btn-outline-danger">Sil</button>
            </div>
        `; 
        listArea.appendChild(yeniSatır);
    });

    // SONUÇLAR
    if(gelirKutusu) gelirKutusu.innerText = toplamGelir + " ₺";
    if(giderKutusu) giderKutusu.innerText = toplamGider + " ₺";
    if(bakiyeKutusu) bakiyeKutusu.innerText = (toplamGelir - toplamGider) + " ₺";
}
// --- GÜVENLİ KUR ÇEKME FONKSİYONU --- // APİ KULLANMAK GEREKTİĞİ İÇİN KOMPLE GEMİNİYLE YAPILDI SADECE KUR KISMI!!!
async function kurlariGetir() {
    const dolarKutusu = document.getElementById("usd");
    const euroKutusu = document.getElementById("eur");
    const altinKutusu = document.getElementById("altin");

    try {
        const istek = await fetch("https://finans.truncgil.com/today.json");
        const sonuc = await istek.json();

        // 1. KONSOLA YAZDIR (F12'de göreceğiz)
        console.log("API'den Gelen Tüm Veri:", sonuc); 

        // 2. VERİYİ GÜVENLİ ÇEK (Hata varsa 'Veri Yok' yazsın)
        // Bazen 'Selling', bazen 'Satış' olarak gelebilir. İkisini de deniyoruz.
        
        // DOLAR
        let dolarDegeri = "---";
        if(sonuc.USD) {
            dolarDegeri = sonuc.USD.Selling || sonuc.USD.Satis || sonuc.USD.Satış;
        }
        dolarKutusu.innerText = dolarDegeri + " ₺";

        // EURO
        let euroDegeri = "---";
        if(sonuc.EUR) {
            euroDegeri = sonuc.EUR.Selling || sonuc.EUR.Satis || sonuc.EUR.Satış;
        }
        euroKutusu.innerText = euroDegeri + " ₺";

        // ALTIN (gram-altin)
        let altinDegeri = "---";
        // JSON anahtarında tire (-) varsa ["key"] şeklinde yazılır
        if(sonuc["gram-altin"]) {
            altinDegeri = sonuc["gram-altin"].Selling || sonuc["gram-altin"].Satis || sonuc["gram-altin"].Satış;
        }
        altinKutusu.innerText = altinDegeri + " ₺";

    } catch (hata) {
        console.log("BÜYÜK HATA:", hata);
    }
}

window.addEventListener("load", function() {
    kurlariGetir();

    setInterval(kurlariGetir, 30000);

});